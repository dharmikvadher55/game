<?php
session_start();

include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username_or_email = $_POST["username_or_email"];
    $password = $_POST["password"];

    // Escape special characters to prevent SQL injection
    $username_or_email = mysqli_real_escape_string($conn, $username_or_email);
    $password = mysqli_real_escape_string($conn, $password);

    // Check if input is email or username
    $login_condition = filter_var($username_or_email, FILTER_VALIDATE_EMAIL) ? "email='$username_or_email'" : "username='$username_or_email'";

    $sql = "SELECT * FROM users WHERE $login_condition AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION["username"] = $row['username'];
        $_SESSION['loggedin'] = true;
       

        header("location: index.php");
        exit;
    } else {
        $error = "Invalid username or password";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Login & Registration Form</title>
  <!---Custom CSS File--->
  <link rel="stylesheet" href="variable.css">

  <style>/* Import Google font - Poppins */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

:root{
            --body: var(--bg-200);
            --card: var(--bg-100);
            --button: var(--primary-100);
            --text: var(--text-200);
            --title: var(--text-100);
            --btntext: var(--bg-200);
            --btnhover: var(--primary-200);
            --border: var(--text-200);
}
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
body{
  min-height: 100vh;
  width: 100%;
  background: var(--body);
}
.container{
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  max-width: 430px;
  width: 100%;
  background: var(--card);
  border-radius: 7px;
  box-shadow: 0 5px 10px rgba(0,0,0,0.3);
}
.container .form{
  padding: 2rem;
}
.form header{
  font-size: 2rem;
  font-weight: 500;
  text-align: center;
  margin-bottom: 1.5rem;
  color: var(--title);
}
 .form input,.button{
   height: 60px;
   width: 100%;
   padding: 0 15px;
   font-size: 17px;
   margin-bottom: 1.3rem;
   border: 1px solid var(--border);
   border-radius: 6px;
   outline: none;
   background:transparent  ;
   color : var(--text)
 }
 .form input:focus{
   box-shadow: 0 1px 0 rgba(0,0,0,0.2);
 }
.form a{
  font-size: 16px;
  color: var(--text);
  text-decoration: none;
}
.form a:hover{
  text-decoration: underline;
  color: var(--button);
}
.button{
  color: var(--btntext);
  background: var(--button);
  font-size: 1.2rem;
  font-weight: 500;
  letter-spacing: 1px;
  margin-top: 1.7rem;
  cursor: pointer;
  transition: 0.4s;
}
.button:hover{
  background: var(--btnhover);

}</style>
</head>
<body><?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    
    
    
    
    
  <div class="container">
    <div class="login form">
      <header>Login</header>
       <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
       
       
       
       
       
             <input type="text" id="username_or_email" name="username_or_email" required>
             
             
        <input type="password" id="password" name="password" required>
        
         <button type="submit" class="button" value ="submit">Login</button>
    </form>
    
    

 <a href="Register.php">Create an account</a>
    
 
      
     
    </div>
  </div>
</body>
</html>