<?php
include '../check.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Flashcards</title>
    <!-- Add your CSS and JavaScript files here -->
</head>
<body>
    <p>hello play</p>
    <!-- Your other HTML content -->
</body>
</html>