<?php
// Database credentials
include 'db_config.php';
// SQL file path
$sqlFilePath = glob('*.sql')[0] ?? null; // path to your .sql file

// Create a connection
$mysqli = new mysqli($host, $user, $password);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Read SQL file
$sql = file_get_contents($sqlFilePath);

if ($sql === false) {
    die("Error reading SQL file");
}

// Split the SQL file into individual queries
$queries = explode(';', $sql);

// Variable to track success
$success = true;

foreach ($queries as $query) {
    $query = trim($query);
    if (!empty($query)) {
        if ($mysqli->query($query)) {
            echo "Query executed successfully:" . $query . "<br><br><br>";
        } else {
            echo "Error executing query: " . $mysqli->error . "<br><br><br>hhp";
            $success = false;
        }
    }
}

// Close the connection
$mysqli->close();

if ($success) {
    echo "all queries executed successfully.";
} else {
    echo "Some queries encountered errors.";
}
?>
