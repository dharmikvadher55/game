<?php
// Start the session
session_start();

if (isset($_SESSION['username'])) {
    // User is logged in
    echo "Welcome, " . $_SESSION['username'];
} else {
    // User is not logged in
    echo "Please log in to access this page.";
}


?>
<!doctype html>
<html lang="en">
<head>
    <title>Bootstrap Demo</title>
    <link href="bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>

@import url('variable.css');

:root{


        --body: var(--bg-200);
        --card: var(--bg-100);
        --footer: var(--primary-100);
        --footertext: var(--text-100);
        --title: var(--text-100);
        --subject: var(--text-200);
        --user: var(--text-200);
    }
        #content {
            
        }
        
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 400px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>

<script>
    var isLoggedIn = <?php echo json_encode($isLoggedIn); ?>;
</script>



<div id="content">
    <?php 
     include 'dashboard.PHP'; ?><a href="logout.php">logout</a>
</div>

<!-- Include common modal HTML -->

<script>
    // Show loader for 3 seconds and then display content
    setTimeout(function() {
        document.getElementById('loader').style.display = 'none';
        document.getElementById('content').style.display = 'block';
    }, 500);

    </script>

<script src="scripts.js"></script>
<script src="bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>


</body>
</html>
